var sidenav = document.querySelector(".side-navbar");

function ShowNavBar() {
    sidenav.style.left = "0";
}

function CloseNavBar() {
    sidenav.style.left = "-60%";
}